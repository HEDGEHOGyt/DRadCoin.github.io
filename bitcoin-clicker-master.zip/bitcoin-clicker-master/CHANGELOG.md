# Changelog

## 1.2.0 - 08.04.2018

- Showing an unit when Bitcoins or Satoshis reached the 1 million border

## Version 1.1. (+ 1.1.1) - 28.03.2018

- Adding a reset button | https://github.com/julianYaman/bitcoin-clicker/commit/d25beb1bef64082129fcb3479144a8638b9429d0
- Big update in the price system (adding a constant multiplier for all prices) | https://github.com/julianYaman/bitcoin-clicker/commit/44ef5d40df37308f8ad4ff0c093982bf3c39c530
- (Repository) Adding content to the README.md file | https://github.com/julianYaman/bitcoin-clicker/commit/6cc18c0ff9ac564e91e4e776e43f35b203d748bc

## Version 1.0 - 17.03.2018

- Initial work files commit | https://github.com/julianYaman/bitcoin-clicker/commit/3ebcbd23f079514eb56ebd59cb9c0e5d493e2220